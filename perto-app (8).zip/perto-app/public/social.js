// Rede social: feed público (fotos, vídeos, curtidas, comentários), histórico de conversas, emojis e reações.
(() => {
const base = () => localStorage.server || '', mu = id => base() + '/media/' + id;
const TYPES = ['image/jpeg', 'image/png', 'image/webp', 'image/gif', 'video/mp4', 'video/webm', 'video/quicktime'];
const EMO = ['😀','😂','😍','🥰','😎','🤔','😢','😡','👍','👏','🙏','🔥','❤️','💔','🎉','😮','😴','🤝','👀','✨','🍕','☕','🎶','🌎'];
const REA = ['❤️','😂','👍','😮','😢','🔥'];
let posts = [], pend = null; const els = {}, openC = new Set();
Object.assign(S.names, JSON.parse(localStorage.names || '{}'));
setInterval(() => localStorage.names = JSON.stringify(S.names), 5000);

document.head.append(h('style', { textContent: `
#nav{display:flex;gap:6px;padding:6px 6px calc(6px + env(safe-area-inset-bottom,0px));border-top:1px solid var(--bd);background:var(--sf)}#nav button{flex:1;padding:8px 4px;font-size:14px}
#feed,#convs{position:absolute;z-index:1050;left:0;right:0;top:calc(60px + env(safe-area-inset-top,0px));bottom:calc(58px + env(safe-area-inset-bottom,0px));background:var(--bg);overflow-y:auto}
.post,.comp{background:var(--sf);border-bottom:8px solid var(--bg);padding:12px 14px;display:flex;flex-direction:column;gap:8px}
.pm{width:100%;max-height:420px;object-fit:contain;background:#000;border-radius:12px}
.cms{display:flex;flex-direction:column;gap:6px;font-size:14px}.rx{font-size:13px;margin-top:4px}
#rp,#ep{position:absolute;z-index:6;bottom:70px;left:12px;right:12px;display:flex;flex-wrap:wrap;gap:4px;justify-content:center;background:var(--sf);border:1px solid var(--bd);border-radius:16px;padding:8px}
#ep button{background:none;font-size:22px;padding:4px 6px}#rp button{padding:6px 10px;font-size:20px}` }));

const pick = cb => { const i = h('input', { type: 'file', accept: 'image/*,video/*' }); i.onchange = () => i.files[0] && cb(i.files[0]); i.click(); };
const shrink = f => new Promise(res => {
  const i = new Image();
  i.onload = () => { const k = Math.min(1, 1280 / Math.max(i.width, i.height)), c = document.createElement('canvas'); c.width = i.width * k; c.height = i.height * k; c.getContext('2d').drawImage(i, 0, 0, c.width, c.height); c.toBlob(b => res(b || f), 'image/jpeg', .82); };
  i.onerror = () => res(f); i.src = URL.createObjectURL(f);
});
async function up(f) {
  if (!TYPES.includes(f.type)) throw new Error('tipo');
  if (f.type.startsWith('image/') && f.type !== 'image/gif') f = await shrink(f);
  const r = await fetch(base() + '/upload', { method: 'POST', headers: { 'x-token': tok, 'Content-Type': f.type }, body: f });
  if (!r.ok) throw new Error('upload');
  return r.json();
}
const bad = () => notify('Não foi possível enviar a mídia (até 30 MB; JPG, PNG, WebP, GIF, MP4, MOV ou WebM).');
const mediaEl = m => m.kind === 'video' ? h('video', { src: m.src || mu(m.id), controls: true, playsInline: true, preload: 'metadata', className: 'pm' }) : h('img', { src: m.src || mu(m.id), loading: 'lazy', className: 'pm' });

// ---- Feed ----
const ptxt = h('textarea', { rows: 2, maxLength: 1000, placeholder: 'Compartilhe algo com todo mundo…' }), pst = h('small');
const feedList = h('div');
const feedEl = h('section', { id: 'feed', hidden: true }, h('div', { className: 'comp' }, ptxt, h('div', { className: 'row' },
  h('button', { className: 'g', textContent: '📷 Foto/vídeo', onclick: () => pick(async f => { notify('Enviando mídia…'); try { pend = await up(f); pst.textContent = 'Mídia anexada ✓' } catch { bad() } }) }),
  h('button', { textContent: 'Publicar', onclick: () => { const t = ptxt.value.trim(); if (!t && !pend) return; send({ t: 'post', text: t, media: pend }); ptxt.value = ''; pend = null; pst.textContent = '' } }), pst)), feedList);
function postEl(p) {
  const el = postEl0(p), hd = el.firstChild;
  if (p.pid !== S.me) hd.append(h('button', { className: 'g', textContent: (S.following || []).includes(p.pid) ? 'Seguindo' : 'Seguir', style: 'margin-left:auto', onclick: () => send({ t: 'follow', to: p.pid }) }), h('button', { className: 'g', textContent: '⚑', onclick: () => FL('post', p.id) }));
  if (p.hidden) el.prepend(h('div', { className: 'rx', textContent: '⚠️ Em análise: oculto para os outros até um moderador decidir.' }), p.case ? h('button', { className: 'g', textContent: 'Enviar justificativa', onclick: () => { const t = prompt('Justifique este conteúdo:'); if (t && t.trim()) send({ t: 'justify', case: p.case, text: t.trim() }) } }) : '');
  return el;
}
function postEl0(p) {
  const liked = p.likes.includes(S.me), cm = h('div', { className: 'cms', hidden: !openC.has(p.id) }, p.comments.map(c => h('div', {}, h('b', { textContent: c.name + ' ' }), c.text)));
  const ci = h('input', { type: 'text', placeholder: 'Comentar…', maxLength: 300 });
  ci.onkeydown = e => { if (e.key === 'Enter' && ci.value.trim()) { send({ t: 'comment', post: p.id, text: ci.value.trim() }); ci.value = '' } };
  cm.append(ci);
  return h('div', { className: 'post' },
    h('div', { className: 'row' }, h('div', { className: 'av', textContent: p.name[0].toUpperCase(), style: 'background:hsl(' + hue(p.name) + ' 60% 42%)' }),
      h('div', {}, h('b', { textContent: p.name }), h('br'), h('small', { textContent: new Date(p.ts).toLocaleString('pt-BR', { dateStyle: 'short', timeStyle: 'short' }) })),
      p.pid === S.me ? h('button', { className: 'g', textContent: 'Apagar', style: 'margin-left:auto', onclick: () => confirm('Apagar esta publicação?') && send({ t: 'delpost', post: p.id }) }) : ''),
    p.text ? h('div', { textContent: p.text }) : '', p.media ? mediaEl(p.media) : '',
    h('div', { className: 'row' }, h('button', { className: 'g', textContent: (liked ? '❤️ ' : '🤍 ') + p.likes.length, onclick: () => send({ t: 'like', post: p.id }) }),
      h('button', { className: 'g', textContent: '💬 ' + p.comments.length, onclick: () => { openC.has(p.id) ? openC.delete(p.id) : openC.add(p.id); cm.hidden = !openC.has(p.id) } })), cm);
}
const drawFeed = () => feedList.replaceChildren(...posts.map(p => els[p.id] = postEl(p)));

// ---- Conversas ----
const convsEl = h('section', { id: 'convs', hidden: true });
function drawConvs() {
  const l = Object.keys(S.chats).filter(id => (S.chats[id] || []).length).map(id => ({ id, last: S.chats[id].slice(-1)[0] })).sort((a, b) => (b.last.ts || 0) - (a.last.ts || 0));
  convsEl.replaceChildren(...(l.length ? l.map(({ id, last }) => h('div', { className: 'card', onclick: () => openChat(id) },
    h('div', { className: 'av', textContent: (S.names[id] || '?')[0].toUpperCase(), style: 'background:hsl(' + hue(S.names[id] || id) + ' 60% 42%)' }),
    h('div', {}, h('b', { textContent: S.names[id] || 'Conversa' }), h('br'), h('small', { textContent: (last.me ? 'Você: ' : '') + (last.t || '📷 Mídia') })))) :
    [h('div', { className: 'pad' }, h('small', { textContent: 'Nenhuma conversa ainda. Toque em alguém no mapa para começar.' }))]));
}
const T = ['map', 'feed', 'convs'];
const nav = h('div', { id: 'nav' }, ...[['map', '🗺️ Mapa'], ['feed', '📰 Feed'], ['convs', '💬 Conversas']].map(([t, l]) => h('button', { textContent: l, className: t === 'map' ? '' : 'g', onclick: () => tab(t) })));
function tab(n) {
  feedEl.hidden = n !== 'feed'; convsEl.hidden = n !== 'convs';
  [...nav.children].forEach((b, i) => b.className = T[i] === n ? '' : 'g');
  if (n === 'feed') send({ t: 'feed' }); if (n === 'convs') drawConvs();
}
$('app').append(feedEl, convsEl, nav);

// ---- Chat: histórico, mídia, emojis e reações ----
window.addM = addM;
function addM(id, m) { const c = S.chats[id] = S.chats[id] || []; if (m.id && c.some(x => x.id === m.id)) return; c.push(m); save(); if (S.open === id) drawChat(); }
function reactPick(x) {
  const o = $('rp'); if (o) o.remove();
  const d = h('div', { id: 'rp' }, ...REA.map(e => h('button', { className: 'g', textContent: e, onclick: () => { send({ t: 'react', to: S.open, mid: x.id, emoji: e }); d.remove() } })), h('button', { className: 'g', textContent: '⚑', onclick: () => { d.remove(); FL('msg', x.id, S.open) } }));
  $('chat').append(d);
}
function bubble(x) {
  const d = h('div', { className: 'b' + (x.me ? ' me' : '') });
  if (x.removed) { d.textContent = '🚫 Mensagem removida pela moderação'; return d; }
  if (x.hidden) { d.append(h('div', { textContent: '⚠️ Mensagem em análise' })); if (x.case) d.append(h('button', { className: 'g', textContent: 'Justificar', onclick: () => { const t = prompt('Justifique esta mensagem:'); if (t && t.trim()) send({ t: 'justify', case: x.case, text: t.trim() }) } })); return d; }
  if (x.st) { d.className += ' stk'; d.append(h('div', { textContent: x.st })); }
  if (x.media) d.append(mediaEl(x.media));
  if (x.t) d.append(h('div', { textContent: x.t }));
  const r = Object.values(x.r || {}); if (r.length) d.append(h('div', { className: 'rx', textContent: r.join(' ') }));
  if (x.id && !S.open.startsWith('n:')) d.onclick = () => reactPick(x);
  return d;
}
drawChat = function () { const m = $('msgs'); m.replaceChildren(...(S.chats[S.open] || []).map(bubble)); m.scrollTop = m.scrollHeight; };
const _open = openChat;
openChat = function (id) { _open(id); phB.hidden = false; $('ep').hidden = true; send({ t: 'hist', with: id }); };
say = function () {
  const v = $('ci').value.trim(); if (!S.open || !v) return;
  const ep = epOf(S.open);   // conectado direto (Bluetooth/Wi-Fi): envia direto; senão, pelo servidor
  if (ep) offOut(ep, v); else send({ t: 'msg', to: S.open, text: v });
  $('ci').value = '';
};
$('cs').onclick = say;
const ep = h('div', { id: 'ep', hidden: true }, ...EMO.map(e => h('button', { textContent: e, onclick: () => { $('ci').value += e; $('ci').focus() } })));
const emoB = h('button', { className: 'g', textContent: '😊', onclick: () => ep.hidden = !ep.hidden });
const phB = h('button', { className: 'g', textContent: '📷', onclick: () => { const ep = epOf(S.open); if (ep) return offPick(ep); pick(async f => { try { send({ t: 'msg', to: S.open, text: '', media: await up(f) }) } catch { bad() } }) } });
$('chat').append(ep); $('cin').prepend(emoB, phB);

// ---- Eventos do servidor ----
const _on = on;
on = function (m) {
  if (m.t === 'welcome') { S.me = m.id; localStorage.me = m.id; }
  else if (m.t === 'msg') { S.names[m.from] = m.name; addM(m.from, { id: m.id, me: false, t: m.text, media: m.media, st: m.st, ts: m.ts }); if (S.open !== m.from) notify(m.name + ': ' + (m.text || '📷'), [['Abrir', () => openChat(m.from)]]); return; }
  else if (m.t === 'sent') return addM(m.to, { id: m.id, me: true, t: m.text, media: m.media, st: m.st, ts: m.ts });
  else if (m.t === 'hist') { const srv = m.list.map(x => ({ id: x.id, me: x.from === S.me, t: x.text, media: x.media, r: x.r, ts: x.ts, st: x.st, hidden: x.hidden, removed: x.removed, case: x.case })), have = new Set(srv.map(x => x.id));
    S.chats[m.with] = srv.concat((S.chats[m.with] || []).filter(x => x.off && !have.has(x.id))).sort((a, b) => (a.ts || 0) - (b.ts || 0)); save(); if (S.open === m.with) drawChat(); return; }
  else if (m.t === 'react') { const x = (S.chats[m.with] || []).find(y => y.id === m.mid); if (x) { x.r = m.r; save(); if (S.open === m.with) drawChat(); } return; }
  else if (m.t === 'offack') { const ob = OB(), e = ob[m.pid]; if (e) { if (m.linked) delete ob[m.pid]; else ob[m.pid] = e.filter(x => !m.ids.includes(x.id)); obSave(ob); } if (m.linked && S.open === m.pid) send({ t: 'hist', with: m.pid }); return; }
  else if (m.t === 'feed') { if (m.videos) { window.onVideos && window.onVideos(m.list); return; } posts = m.list; drawFeed(); return; }
  else if (m.t === 'post') { posts.unshift(m.p); drawFeed(); return; }
  else if (m.t === 'postupd') { const i = posts.findIndex(x => x.id === m.p.id); if (i >= 0) { posts[i] = m.p; const n = postEl(m.p); if (els[m.p.id]) els[m.p.id].replaceWith(n); els[m.p.id] = n } else { posts.unshift(m.p); drawFeed(); } return; }
  else if (m.t === 'postdel') { posts = posts.filter(x => x.id !== m.post); drawFeed(); return; }
  _on(m);
};
window.drawConvs = drawConvs; window.mediaEl = mediaEl; window.pick = pick; window.up = up; window.bad = bad;
window.FL = (kind, id, w) => { const r = prompt('Por que você está denunciando isto? (imoral, risco, golpe…)'); if (r && r.trim()) send({ t: 'flag', kind, id, with: w, reason: r.trim() }); };
})();
