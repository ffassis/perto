// Match (deslizar), vídeos em tela cheia, stories, figurinhas, seguir e avisos de moderação.
(() => {
const STK = ['🥳','😻','🤣','😭','😡','🥰','😎','🙌','💪','🎉','🔥','💯','🤝','🙈','🍻','🫶','🤔','😴','🤯','👻'];
const mu = id => (localStorage.server || '') + '/media/' + id;
S.following = [];
document.head.append(h('style', { textContent: `
#vid,#match{position:absolute;z-index:1050;left:0;right:0;top:calc(60px + env(safe-area-inset-top,0px));bottom:calc(58px + env(safe-area-inset-bottom,0px));background:var(--bg);overflow-y:auto}
#vid{background:#000;scroll-snap-type:y mandatory}.vi{position:relative;height:100%;scroll-snap-align:start;display:flex;background:#000}.vi video{width:100%;height:100%;object-fit:contain}
.vo{position:absolute;left:12px;bottom:24px;right:84px;color:#fff;text-shadow:0 1px 3px #000}.vb{position:absolute;right:8px;bottom:24px;display:flex;flex-direction:column;gap:8px}
#nav button{white-space:pre-line;font-size:11px;line-height:1.2;padding:6px 2px}
#sv{position:fixed;inset:0;z-index:3000;background:#000;display:flex;align-items:center;justify-content:center}#sv img,#sv video{max-width:100%;max-height:100%}
.sc{position:absolute;bottom:24px;left:16px;right:16px;color:#fff;text-shadow:0 1px 3px #000}.sx{position:absolute;top:16px;right:16px}.sf{position:absolute;top:16px;left:16px}
.mc{border-radius:18px;overflow:hidden;background:var(--sf);border:1px solid var(--bd);touch-action:pan-y;user-select:none}.mc img{width:100%;max-height:60vh;object-fit:cover;display:block;pointer-events:none}.mi{padding:12px}
.b.stk{background:none;border:0;font-size:64px;line-height:1.1;padding:0}#sp{position:absolute;z-index:6;bottom:70px;left:12px;right:12px;display:flex;flex-wrap:wrap;gap:4px;justify-content:center;background:var(--sf);border:1px solid var(--bd);border-radius:16px;padding:8px}#sp button{background:none;font-size:34px;padding:2px 6px}` }));

// ---- navegação com 5 abas ----
$('nav').remove();
const T = [['map', '🗺️', 'Mapa'], ['feed', '📰', 'Feed'], ['vid', '🎬', 'Vídeos'], ['match', '💘', 'Match'], ['convs', '💬', 'Chats']];
const views = { feed: $('feed'), convs: $('convs'), vid: h('section', { id: 'vid', hidden: true }), match: h('section', { id: 'match', hidden: true }) };
let fsel = 'all';
const nav = h('div', { id: 'nav' }, ...T.map(([t, e, l]) => h('button', { textContent: e + '\n' + l, className: t === 'map' ? '' : 'g', onclick: () => tab(t) })));
function tab(n) {
  for (const k in views) views[k].hidden = k !== n;
  [...nav.children].forEach((b, i) => b.className = T[i][0] === n ? '' : 'g');
  if (n === 'feed') { send({ t: 'feed', only: fsel }); send({ t: 'stories' }); }
  if (n === 'vid') send({ t: 'feed', videos: true });
  if (n === 'match') send({ t: 'myprof' });
  if (n === 'convs') drawConvs();
}
$('app').append(views.vid, views.match, nav);

// ---- stories ----
let stories = [];
const chips = h('div', { className: 'row', style: 'overflow-x:auto' });
const fb = (v, l) => h('button', { className: 'g', textContent: l, onclick: () => { fsel = v; send({ t: 'feed', only: v }) } });
views.feed.prepend(h('div', { className: 'comp' }, h('div', { className: 'row' }, fb('all', 'Todos'), fb('following', 'Seguindo'),
  h('button', { className: 'g', textContent: '＋ Story', onclick: () => pick(async f => { try { send({ t: 'story', media: await up(f) }) } catch { bad() } }) })), chips));
function drawChips() {
  const by = {}; stories.forEach(s => (by[s.pid] = by[s.pid] || []).push(s));
  chips.replaceChildren(...Object.values(by).map(l => h('button', { className: 'g', textContent: l[0].pid === S.me ? 'Você' : l[0].name, onclick: () => openStory(l, 0) })));
}
function closeStory() { const o = $('sv'); if (o) o.remove(); }
function openStory(l, i) {
  closeStory(); const s = l[i], mine = s.pid === S.me;
  if (!mine) send({ t: 'sview', id: s.id });
  const v = h('div', { id: 'sv' }, mediaEl(s.media), h('div', { className: 'sc', textContent: s.name + (s.text ? ' · ' + s.text : '') + (mine ? ' · 👁 ' + s.views : '') + (s.hidden ? ' · ⚠️ em análise' : '') }),
    h('button', { className: 'g sx', textContent: '✕', onclick: closeStory }), mine ? '' : h('button', { className: 'g sf', textContent: '⚑', onclick: () => { closeStory(); FL('story', s.id) } }));
  v.onclick = e => { if (e.target === v || e.target.tagName === 'IMG') l[i + 1] ? openStory(l, i + 1) : closeStory(); };
  document.body.append(v);
}

// ---- vídeos em tela cheia ----
let io = null; const vids = {};
function vidEl(p) {
  const vd = h('video', { src: mu(p.media.id), loop: true, muted: true, playsInline: true, preload: 'metadata' }); vd.onclick = () => vd.muted = !vd.muted;
  const lk = h('button', { className: 'g', onclick: () => send({ t: 'like', post: p.id }) }), cm = h('button', { className: 'g', onclick: () => { const t = prompt('Comentar:'); if (t && t.trim()) send({ t: 'comment', post: p.id, text: t.trim() }) } });
  const el = h('div', { className: 'vi' }, vd, h('div', { className: 'vo' }, h('b', { textContent: p.name }), h('div', { textContent: p.text })),
    h('div', { className: 'vb' }, lk, cm, h('button', { className: 'g', textContent: '⚑', onclick: () => FL('post', p.id) })));
  el.upd = q => { lk.textContent = (q.likes.includes(S.me) ? '❤️ ' : '🤍 ') + q.likes.length; cm.textContent = '💬 ' + q.comments.length; }; el.upd(p); vids[p.id] = el; return el;
}
window.onVideos = list => {
  const v = views.vid; io && io.disconnect();
  v.replaceChildren(...(list.length ? list.map(vidEl) : [h('div', { className: 'pad', style: 'color:#fff', textContent: 'Ainda não há vídeos. Publique um no Feed (📷).' })]));
  io = new IntersectionObserver(es => es.forEach(e => { const m = e.target.querySelector('video'); if (m) e.isIntersecting ? m.play().catch(() => {}) : m.pause() }), { root: v, threshold: .7 });
  v.querySelectorAll('.vi').forEach(x => io.observe(x));
};

// ---- Match (só adultos) ----
let prof = null, deck = [];
function swipe(like) { const c = deck.shift(); send({ t: 'swipe', to: c.pid, like }); if (!deck.length) send({ t: 'deck' }); drawMatch(); }
function drawMatch() {
  const m = views.match;
  if (!prof) {
    const bio = h('textarea', { rows: 3, maxLength: 300, placeholder: 'Fale um pouco sobre você…' }), ad = h('input', { type: 'checkbox' }), st = h('small'); let ph = null;
    return m.replaceChildren(h('div', { className: 'comp' }, h('b', { textContent: 'Criar perfil de Match' }), h('small', { textContent: 'Só para maiores de 18 anos. Nome, foto e bio aparecem para outros adultos.' }), bio,
      h('div', { className: 'row' }, h('button', { className: 'g', textContent: '📷 Foto de perfil', onclick: () => pick(async f => { try { ph = await up(f); st.textContent = 'Foto anexada ✓' } catch { bad() } }) }), st),
      h('label', { className: 'row' }, ad, h('span', { textContent: 'Confirmo que tenho 18 anos ou mais' })),
      h('button', { textContent: 'Salvar e começar', onclick: () => { if (!ad.checked || !ph) return notify('Confirme a idade e escolha uma foto.'); send({ t: 'profile', bio: bio.value, photo: ph, adult: true }) } })));
  }
  if (!deck.length) return m.replaceChildren(h('div', { className: 'pad' }, h('p', { textContent: 'Sem mais perfis por enquanto. Volte mais tarde!' }), h('button', { className: 'g', textContent: 'Atualizar', onclick: () => send({ t: 'deck' }) })));
  const c = deck[0], card = h('div', { className: 'mc' }, h('img', { src: mu(c.photo.id) }), h('div', { className: 'mi' }, h('b', { textContent: c.name + (c.d ? ' · ~' + c.d + ' km' : '') }), h('div', { textContent: c.bio })));
  let x0 = null;
  card.onpointerdown = e => { x0 = e.clientX; card.setPointerCapture(e.pointerId) };
  card.onpointermove = e => { if (x0 !== null) { const d = e.clientX - x0; card.style.transform = 'translateX(' + d + 'px) rotate(' + d / 20 + 'deg)' } };
  card.onpointerup = e => { if (x0 === null) return; const d = e.clientX - x0; x0 = null; if (Math.abs(d) > 90) swipe(d > 0); else card.style.transform = '' };
  m.replaceChildren(h('div', { className: 'pad' }, card, h('div', { className: 'row', style: 'justify-content:center;margin-top:12px' },
    h('button', { className: 'g', textContent: '✖', onclick: () => swipe(false) }), h('button', { textContent: '❤️', onclick: () => swipe(true) }), h('button', { className: 'g', textContent: '⚑', onclick: () => FL('profile', c.pid) }))));
}

// ---- figurinhas ----
const sp = h('div', { id: 'sp', hidden: true }, ...STK.map(s => h('button', { textContent: s, onclick: () => { send({ t: 'msg', to: S.open, st: s }); sp.hidden = true } })));
$('chat').append(sp);
$('cin').prepend(h('button', { className: 'g', textContent: '🎭', onclick: () => { sp.hidden = !sp.hidden; $('ep').hidden = true } }));

// ---- dica de instalação no iPhone (Safari) ----
if (/iPhone|iPad/.test(navigator.userAgent) && !navigator.standalone && !window.Capacitor) $('login').append(h('small', { textContent: 'No iPhone: toque em Compartilhar › Adicionar à Tela de Início para instalar o Perto e receber avisos.' }));

// ---- eventos ----
const _on = on;
on = function (m) {
  switch (m.t) {
    case 'following': S.following = m.list; if (!views.feed.hidden) send({ t: 'feed', only: fsel }); return;
    case 'stories': stories = m.list; drawChips(); return;
    case 'profile': prof = m.p; if (prof && !deck.length) send({ t: 'deck' }); drawMatch(); return;
    case 'deck': deck = m.list; drawMatch(); return;
    case 'match': S.names[m.pid] = m.name; notify('💘 Deu match com ' + m.name + '!', [['Conversar', () => openChat(m.pid)]]); return;
    case 'info': notify(m.msg); return;
    case 'review': notify('Seu conteúdo foi denunciado e ficou oculto até a análise de um moderador.', [['Justificar', () => { const t = prompt('Justifique o conteúdo:'); if (t && t.trim()) send({ t: 'justify', case: m.case, text: t.trim() }) }], ['Depois', () => {}, 1]]); return;
    case 'msgmod': {
      const c = S.chats[m.with] || [], i = c.findIndex(x => x.id === m.m.id);
      if (i >= 0) { const o = c[i]; c[i] = { id: o.id, me: o.me, ts: o.ts, r: o.r, t: m.m.text, media: m.m.media, st: m.m.st, hidden: m.m.hidden, removed: m.m.removed, case: m.m.case }; save(); if (S.open === m.with) drawChat(); }
      return;
    }
    case 'postupd': if (vids[m.p.id]) vids[m.p.id].upd(m.p); break;
  }
  _on(m);
};
})();
