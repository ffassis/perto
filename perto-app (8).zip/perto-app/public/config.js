// Endereço do servidor que o app (APK) usa por padrão. O GitHub preenche isto sozinho se você criar a variável SERVER_URL.
window.PERTO_SERVER = '';
if (!localStorage.server && window.PERTO_SERVER) localStorage.server = window.PERTO_SERVER;
