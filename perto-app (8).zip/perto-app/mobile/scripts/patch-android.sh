#!/usr/bin/env bash
# Rode depois de "npx cap add android": instala o plugin de conversa direta (Nearby) no projeto Android.
set -e
A=android/app
D=$A/src/main/java/com/perto/app
mkdir -p "$D"
cp plugin/NearbyPlugin.java "$D/NearbyPlugin.java"
cat > "$D/MainActivity.java" <<'JAVA'
package com.perto.app;

import android.os.Bundle;
import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {
    @Override
    public void onCreate(Bundle savedInstanceState) {
        registerPlugin(NearbyPlugin.class);
        super.onCreate(savedInstanceState);
    }
}
JAVA
grep -q play-services-nearby $A/build.gradle || sed -i "/^dependencies {/a\\    implementation 'com.google.android.gms:play-services-nearby:19.3.0'" $A/build.gradle
python3 - <<'PY'
p = 'android/app/src/main/AndroidManifest.xml'
s = open(p, encoding='utf-8').read()
if 'NEARBY_WIFI_DEVICES' not in s:
    n = ['ACCESS_FINE_LOCATION', 'ACCESS_WIFI_STATE', 'CHANGE_WIFI_STATE', 'BLUETOOTH_SCAN', 'BLUETOOTH_ADVERTISE', 'BLUETOOTH_CONNECT', 'NEARBY_WIFI_DEVICES']
    add = ''.join('<uses-permission android:name="android.permission.%s" />\n    ' % x for x in n)
    add += ''.join('<uses-permission android:name="android.permission.%s" android:maxSdkVersion="30" />\n    ' % x for x in ['BLUETOOTH', 'BLUETOOTH_ADMIN'])
    add += '<uses-permission android:name="android.permission.WRITE_EXTERNAL_STORAGE" android:maxSdkVersion="28" />\n    '
    s = s.replace('<application', add + '<application', 1)
    open(p, 'w', encoding='utf-8').write(s)
PY
echo "Android pronto."
