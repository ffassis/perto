package com.perto.app;

import android.Manifest;
import android.os.Build;
import androidx.annotation.NonNull;
import androidx.core.app.ActivityCompat;
import com.getcapacitor.JSObject;
import com.getcapacitor.Plugin;
import com.getcapacitor.PluginCall;
import com.getcapacitor.PluginMethod;
import com.getcapacitor.annotation.CapacitorPlugin;
import com.google.android.gms.nearby.Nearby;
import com.google.android.gms.nearby.connection.AdvertisingOptions;
import com.google.android.gms.nearby.connection.ConnectionInfo;
import com.google.android.gms.nearby.connection.ConnectionLifecycleCallback;
import com.google.android.gms.nearby.connection.ConnectionResolution;
import com.google.android.gms.nearby.connection.ConnectionsClient;
import com.google.android.gms.nearby.connection.DiscoveredEndpointInfo;
import com.google.android.gms.nearby.connection.DiscoveryOptions;
import com.google.android.gms.nearby.connection.EndpointDiscoveryCallback;
import com.google.android.gms.nearby.connection.Payload;
import com.google.android.gms.nearby.connection.PayloadCallback;
import com.google.android.gms.nearby.connection.PayloadTransferUpdate;
import com.google.android.gms.nearby.connection.Strategy;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import android.app.Activity;
import android.content.ContentResolver;
import android.content.Intent;
import android.net.Uri;
import androidx.activity.result.ActivityResult;
import com.getcapacitor.annotation.ActivityCallback;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import org.json.JSONObject;

/**
 * Conversa direta entre celulares, sem internet. O Google Nearby Connections escolhe sozinho
 * Bluetooth, BLE ou Wi-Fi direto, conforme o que cada aparelho suporta.
 */
@CapacitorPlugin(name = "Nearby")
public class NearbyPlugin extends Plugin {
    private static final String SVC = "com.perto.app";
    private final Map<String, String> names = new HashMap<>();
    private final Set<String> mine = new HashSet<>(); // conexões que eu iniciei
    private ConnectionsClient c;
    private String me = "Perto";
    private static final long MAX = 50L * 1024 * 1024;   // limite por arquivo
    private final Map<String, JSONObject> metas = new HashMap<>();   // dados do arquivo (nome, tipo), por id do payload
    private final Map<String, Payload> recv = new HashMap<>();
    private final Map<String, String> from = new HashMap<>();
    private final Set<String> done = new HashSet<>();
    private final Map<String, String> sending = new ConcurrentHashMap<>();

    private void emit(String ev, String id, String state, String text) {
        JSObject o = new JSObject();
        o.put("id", id);
        o.put("name", names.get(id));
        if (state != null) o.put("state", state);
        if (text != null) o.put("text", text);
        notifyListeners(ev, o);
    }

    private final PayloadCallback pay = new PayloadCallback() {
        @Override public void onPayloadReceived(@NonNull String id, @NonNull Payload p) {
            if (p.getType() == Payload.Type.FILE) {
                String pid = String.valueOf(p.getId());
                recv.put(pid, p); from.put(pid, id); finish(pid);
            } else if (p.getType() == Payload.Type.BYTES) {
                String s = new String(p.asBytes(), StandardCharsets.UTF_8);
                try {
                    JSONObject j = new JSONObject(s);
                    if ("f".equals(j.optString("k"))) {      // aviso que um arquivo vem a seguir
                        String pid = j.optString("pid");
                        metas.put(pid, j); from.put(pid, id);
                        JSObject o = new JSObject(); o.put("id", id); o.put("name", names.get(id));
                        notifyListeners("filestart", o);
                        finish(pid);
                        return;
                    }
                } catch (Exception ignored) { }
                emit("msg", id, null, s);
            }
        }
        @Override public void onPayloadTransferUpdate(@NonNull String id, @NonNull PayloadTransferUpdate u) {
            int st = u.getStatus();
            String pid = String.valueOf(u.getPayloadId());
            if (st == PayloadTransferUpdate.Status.SUCCESS) {
                if (sending.containsKey(pid)) {
                    JSObject o = new JSObject(); o.put("mid", sending.remove(pid)); o.put("status", "done");
                    notifyListeners("fileout", o);
                } else { done.add(pid); finish(pid); }
            } else if (st == PayloadTransferUpdate.Status.FAILURE || st == PayloadTransferUpdate.Status.CANCELED) {
                JSObject o = new JSObject(); o.put("status", "fail");
                String mid = sending.remove(pid); if (mid != null) o.put("mid", mid);
                notifyListeners("fileout", o);
            }
        }
    };

    private final ConnectionLifecycleCallback life = new ConnectionLifecycleCallback() {
        @Override public void onConnectionInitiated(@NonNull String id, @NonNull ConnectionInfo info) {
            names.put(id, info.getEndpointName());
            if (mine.contains(id)) {
                c.acceptConnection(id, pay);          // quem pediu já aceita; quem recebe decide
            } else {
                emit("request", id, null, null);
            }
        }
        @Override public void onConnectionResult(@NonNull String id, @NonNull ConnectionResolution r) {
            mine.remove(id);
            emit("state", id, r.getStatus().isSuccess() ? "connected" : "rejected", null);
        }
        @Override public void onDisconnected(@NonNull String id) {
            emit("state", id, "disconnected", null);
        }
    };

    private final EndpointDiscoveryCallback disc = new EndpointDiscoveryCallback() {
        @Override public void onEndpointFound(@NonNull String id, @NonNull DiscoveredEndpointInfo i) {
            names.put(id, i.getEndpointName());
            emit("found", id, null, null);
        }
        @Override public void onEndpointLost(@NonNull String id) {
            emit("lost", id, null, null);
        }
    };

    private boolean ready(PluginCall call) {
        if (c == null) { call.reject("Modo offline não iniciado"); return false; }
        return true;
    }

    @PluginMethod
    public void ask(PluginCall call) {
        List<String> p = new ArrayList<>();
        p.add(Manifest.permission.ACCESS_FINE_LOCATION);
        if (Build.VERSION.SDK_INT >= 31) {
            p.add(Manifest.permission.BLUETOOTH_SCAN);
            p.add(Manifest.permission.BLUETOOTH_ADVERTISE);
            p.add(Manifest.permission.BLUETOOTH_CONNECT);
        }
        if (Build.VERSION.SDK_INT >= 33) p.add(Manifest.permission.NEARBY_WIFI_DEVICES);
        if (Build.VERSION.SDK_INT <= 28) p.add(Manifest.permission.WRITE_EXTERNAL_STORAGE);
        ActivityCompat.requestPermissions(getActivity(), p.toArray(new String[0]), 4242);
        call.resolve();
    }

    @PluginMethod
    public void start(PluginCall call) {
        me = call.getString("name", "Perto");
        if (c == null) c = Nearby.getConnectionsClient(getContext());
        c.stopAdvertising();
        c.stopDiscovery();
        Strategy s = Strategy.P2P_CLUSTER;
        c.startAdvertising(me, SVC, life, new AdvertisingOptions.Builder().setStrategy(s).build())
            .addOnSuccessListener(x -> c.startDiscovery(SVC, disc, new DiscoveryOptions.Builder().setStrategy(s).build())
                .addOnSuccessListener(y -> call.resolve())
                .addOnFailureListener(e -> call.reject(String.valueOf(e.getMessage()))))
            .addOnFailureListener(e -> call.reject(String.valueOf(e.getMessage())));
    }

    @PluginMethod
    public void stop(PluginCall call) {
        if (c != null) { c.stopAdvertising(); c.stopDiscovery(); c.stopAllEndpoints(); }
        mine.clear();
        call.resolve();
    }

    @PluginMethod
    public void connect(PluginCall call) {
        if (!ready(call)) return;
        final String id = call.getString("id");
        mine.add(id);
        c.requestConnection(me, id, life)
            .addOnSuccessListener(x -> call.resolve())
            .addOnFailureListener(e -> { mine.remove(id); call.reject(String.valueOf(e.getMessage())); });
    }

    @PluginMethod
    public void respond(PluginCall call) {
        if (!ready(call)) return;
        String id = call.getString("id");
        if (Boolean.TRUE.equals(call.getBoolean("accept"))) c.acceptConnection(id, pay);
        else c.rejectConnection(id);
        call.resolve();
    }

    @PluginMethod
    public void send(PluginCall call) {
        if (!ready(call)) return;
        String text = call.getString("text", "");
        c.sendPayload(call.getString("id"), Payload.fromBytes(text.getBytes(StandardCharsets.UTF_8)));
        call.resolve();
    }

    private File inbox() { File d = new File(getContext().getFilesDir(), "inbox"); d.mkdirs(); return d; }

    private static String ext(String mime) {
        String e = mime.substring(mime.indexOf('/') + 1);
        if (e.equals("jpeg")) e = "jpg";
        return e.matches("[a-z0-9]{1,5}") ? e : "bin";
    }

    /** Arquivo recebido por completo (aviso + conteúdo): copia para a pasta do app e avisa o JavaScript. */
    private void finish(String pid) {
        final JSONObject j = metas.get(pid); final Payload p = recv.get(pid);
        if (j == null || p == null || !done.contains(pid)) return;
        metas.remove(pid); recv.remove(pid); done.remove(pid);
        final String ep = from.remove(pid);
        new Thread(() -> {
            try {
                String mid = j.optString("mid"), mime = j.optString("mime");
                if (!mid.matches("[a-f0-9]{16}") || !(mime.startsWith("image/") || mime.startsWith("video/"))) return;
                File out = new File(inbox(), mid + "." + ext(mime));
                Payload.File pf = p.asFile();
                Uri u = Build.VERSION.SDK_INT >= 29 ? pf.asUri() : null;
                ContentResolver cr = getContext().getContentResolver();
                try (InputStream in = u != null ? cr.openInputStream(u) : new FileInputStream(pf.asJavaFile());
                     OutputStream os = new FileOutputStream(out)) {
                    byte[] buf = new byte[65536]; int r; long n = 0;
                    while ((r = in.read(buf)) > 0) { n += r; if (n > MAX) throw new IOException("grande"); os.write(buf, 0, r); }
                }
                if (u != null) { try { cr.delete(u, null, null); } catch (Exception ignored) { } }
                JSObject o = new JSObject(); o.put("id", ep); o.put("mid", mid); o.put("mime", mime); o.put("path", out.getAbsolutePath());
                notifyListeners("filein", o);
            } catch (Exception e) {
                JSObject o = new JSObject(); o.put("status", "fail"); notifyListeners("fileout", o);
            }
        }).start();
    }

    /** Abre a galeria do Android; a foto ou o vídeo escolhido é enviado direto por Bluetooth/Wi-Fi (até 50 MB). */
    @PluginMethod
    public void pickAndSend(PluginCall call) {
        if (!ready(call)) return;
        Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        i.addCategory(Intent.CATEGORY_OPENABLE);
        i.setType("*/*");
        i.putExtra(Intent.EXTRA_MIME_TYPES, new String[]{"image/*", "video/*"});
        startActivityForResult(call, i, "pickResult");
    }

    @ActivityCallback
    private void pickResult(PluginCall call, ActivityResult result) {
        if (call == null) return;
        Intent data = result.getData();
        if (result.getResultCode() != Activity.RESULT_OK || data == null || data.getData() == null) { call.reject("cancelado"); return; }
        final Uri uri = data.getData();
        final String id = call.getString("id");
        new Thread(() -> {
            try {
                ContentResolver cr = getContext().getContentResolver();
                String mime = cr.getType(uri);
                if (mime == null || !(mime.startsWith("image/") || mime.startsWith("video/"))) { call.reject("Escolha uma foto ou um vídeo."); return; }
                String mid = UUID.randomUUID().toString().replace("-", "").substring(0, 16);
                File f = new File(inbox(), mid + "." + ext(mime));
                long n = 0;
                try (InputStream in = cr.openInputStream(uri); OutputStream os = new FileOutputStream(f)) {
                    byte[] buf = new byte[65536]; int r;
                    while ((r = in.read(buf)) > 0) { n += r; if (n > MAX) throw new IOException("grande"); os.write(buf, 0, r); }
                } catch (IOException e) { f.delete(); call.reject("Arquivo maior que 50 MB."); return; }
                Payload fp = Payload.fromFile(f);
                JSObject meta = new JSObject();
                meta.put("k", "f"); meta.put("pid", String.valueOf(fp.getId())); meta.put("mime", mime); meta.put("mid", mid);
                sending.put(String.valueOf(fp.getId()), mid);
                c.sendPayload(id, Payload.fromBytes(meta.toString().getBytes(StandardCharsets.UTF_8)));
                c.sendPayload(id, fp);
                JSObject o = new JSObject();
                o.put("mid", mid); o.put("path", f.getAbsolutePath()); o.put("name", f.getName()); o.put("mime", mime);
                call.resolve(o);
            } catch (Exception e) { call.reject(String.valueOf(e.getMessage())); }
        }).start();
    }
}
